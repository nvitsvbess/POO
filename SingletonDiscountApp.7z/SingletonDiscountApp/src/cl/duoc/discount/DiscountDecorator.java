package cl.duoc.discount;

import cl.duoc.domain.ShoppingCart;

// Clase abstracta que envuelve un DiscountComponent
public abstract class DiscountDecorator implements DiscountComponent {
    protected DiscountComponent component;

    public DiscountDecorator(DiscountComponent component) {
        this.component = component;
    }

    @Override
    public double applyDiscount(ShoppingCart cart) {
        return component.applyDiscount(cart);
    }
}