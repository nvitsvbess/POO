package cl.duoc.discount;

import cl.duoc.domain.ShoppingCart;

// Aplica 10% sobre el total
public class TenPercentDecorator extends DiscountDecorator {
    public TenPercentDecorator(DiscountComponent component) {
        super(component);
    }

    @Override
    public double applyDiscount(ShoppingCart cart) {
        double base = super.applyDiscount(cart);
        return base * 0.90;
    }
}