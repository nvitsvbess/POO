package cl.duoc.discount;

import cl.duoc.domain.ShoppingCart;

// Implementación base: no aplica descuentos, solo retorna subtotal.
public class BaseDiscount implements DiscountComponent {
    @Override
    public double applyDiscount(ShoppingCart cart) {
        return cart.getSubtotal();
    }
}