package cl.duoc.discount;

import cl.duoc.domain.ShoppingCart;
import java.util.*;

// SINGLETON: una única instancia global y controlada.
// - Constructor privado
// - getInstance() estático con Double-Checked Locking (DCL) para hilos
// - Mantiene estrategias registradas y proceso de cálculo total de descuento
public class DiscountManager {
    private static volatile DiscountManager INSTANCE; // volatile para DCL

    private final List<DiscountStrategy> strategies = new ArrayList<>(); // Estrategias activas

    private DiscountManager() {
        // Carga inicial de reglas: puedes leer desde BD/archivo en el futuro
        strategies.add(new PercentageDiscount(0.05));           // 5% general
        strategies.add(new CategoryDiscount("POLERAS", 0.10));  // 10% poleras
        // strategies.add(new FixedAmountDiscount(2000));       // ejemplo monto fijo
    }

    public static DiscountManager getInstance() {
        if (INSTANCE == null) {                    // 1er check (rápido)
            synchronized (DiscountManager.class) { // sincroniza sólo al crear
                if (INSTANCE == null) {
                    INSTANCE = new DiscountManager();
                }
            }
        }
        return INSTANCE;
    }

    // Permite agregar/quitar estrategias en runtime si se requiere (extensible)
    public void registerStrategy(DiscountStrategy strategy) { strategies.add(strategy); }
    public void clearStrategies() { strategies.clear(); }

    // Calcula el descuento total sumando el aporte de cada estrategia.
    public double computeTotalDiscount(ShoppingCart cart) {
        return strategies.stream()
                .mapToDouble(s -> s.computeDiscount(cart))
                .sum();
    }

    // Retorna nombres de reglas aplicadas (útil para imprimir en consola)
    public List<String> getActiveStrategyNames() {
        return strategies.stream().map(DiscountStrategy::getName).toList();
    }
}