package cl.duoc.command;

import java.util.*;

// Invocador: ejecuta comandos en orden
public class Invoker {
    private List<Command> commands = new ArrayList<>();

    public void addCommand(Command c) { commands.add(c); }

    public void runCommands() {
        commands.forEach(Command::execute);
        commands.clear();
    }
}