package cl.duoc.command;

// Interfaz para todos los comandos
public interface Command {
    void execute();
}