package cl.duoc.shop;



import cl.duoc.discount.DiscountManager;
import cl.duoc.domain.Order;
import cl.duoc.domain.Product;
import cl.duoc.domain.ShoppingCart;
import cl.duoc.service.OrderService;

// Clase de arranque (demo por consola)
public class Main {
    public static void main(String[] args) {
        // 1) Crear productos de ejemplo
        Product p1 = new Product("SKU-001", "Polera Negra", "POLERAS", 9990);
        Product p2 = new Product("SKU-002", "Pantalón Cargo", "PANTALONES", 19990);

        // 2) Armar carrito
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(p1, 2); // 2 poleras
        cart.addItem(p2, 1); // 1 pantalón

        // 3) Mostrar estrategias activas (desde el Singleton)
        System.out.println("Reglas activas: " + DiscountManager.getInstance().getActiveStrategyNames());

        // 4) Checkout
        OrderService service = new OrderService();
        Order order = service.checkout(cart);

        // 5) Imprimir resumen (consola)
        System.out.println("Subtotal: CLP " + order.getSubtotal());
        System.out.println("Descuentos: CLP " + order.getTotalDiscount());
        System.out.println("Total a pagar: CLP " + order.getTotalToPay());
        System.out.println("Fecha: " + order.getCreatedAt());
    }
}