package cl.duoc.domain;

// Representa una línea del carrito: el producto y cuántas unidades.
// Responsabilidad: encapsular el cálculo de subtotal (precio * cantidad).
public class CartItem {
    private final Product product;
    private final int quantity; // Cantidad no negativa; valida antes de crear

    public CartItem(Product product, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("quantity debe ser > 0");
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }

    public double getSubtotal() {
        return product.getPrice() * quantity; // Cálculo local del subtotal
    }
}