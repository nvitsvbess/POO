package cl.duoc.domain;

import java.util.*;

// Carrito en memoria: agrega y quita ítems.
// Mantiene una lista mutable interna, pero expone solo lectura para no romper el encapsulamiento.
public class ShoppingCart {
    private final List<CartItem> items = new ArrayList<>();

    public void addItem(Product product, int quantity) {
        items.add(new CartItem(product, quantity));
    }

    public void removeItemByProductId(String productId) {
        items.removeIf(ci -> ci.getProduct().getId().equals(productId));
    }

    public List<CartItem> getItems() {
        return Collections.unmodifiableList(items); // Seguridad: no exponer lista mutable
    }

    public double getSubtotal() {
        return items.stream().mapToDouble(CartItem::getSubtotal).sum();
    }

    public boolean isEmpty() { return items.isEmpty(); }
}