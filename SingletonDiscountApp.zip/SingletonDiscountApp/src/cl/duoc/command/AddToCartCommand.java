package cl.duoc.command;

import cl.duoc.domain.*;

public class AddToCartCommand implements Command {
    private final ShoppingCart cart;
    private Product product;
    private final int quantity;

    public AddToCartCommand(ShoppingCart cart, Product product, int quantity) {
        this.cart = cart;
        this.product = product;
        this.quantity = quantity;
    }

    @Override
    public void execute() {
        cart.addItem(prod   uct, quantity);
    }
}