package cl.duoc.command;

import cl.duoc.domain.ShoppingCart;

public class RemoveFromCartCommand implements Command {
    private ShoppingCart cart;
    private String productId;

    public RemoveFromCartCommand(ShoppingCart cart, String productId) {
        this.cart = cart;
        this.productId = productId;
    }

    @Override
    public void execute() {
        cart.removeItemByProductId(productId);
    }
}