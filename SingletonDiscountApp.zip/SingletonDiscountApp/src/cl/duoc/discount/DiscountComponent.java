package cl.duoc.discount;

import cl.duoc.domain.ShoppingCart;

// Componente base para aplicar descuentos
public interface DiscountComponent {
    double applyDiscount(ShoppingCart cart);
}