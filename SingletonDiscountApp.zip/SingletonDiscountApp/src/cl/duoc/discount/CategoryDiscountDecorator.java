package cl.duoc.discount;

import cl.duoc.domain.*;

// Aplica descuento a una categoría específica
public class CategoryDiscountDecorator extends DiscountDecorator {
    private String category;
    private double percentage;

    public CategoryDiscountDecorator(DiscountComponent component, String category, double percentage) {
        super(component);
        this.category = category;
        this.percentage = percentage;
    }

    @Override
    public double applyDiscount(ShoppingCart cart) {
        double base = super.applyDiscount(cart);
        double discount = cart.getItems().stream()
            .filter(ci -> ci.getProduct().getCategory().equalsIgnoreCase(category))
            .mapToDouble(CartItem::getSubtotal)
            .sum() * percentage;
        return base - discount;
    }
}