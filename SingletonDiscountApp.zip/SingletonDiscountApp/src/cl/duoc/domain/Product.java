package cl.duoc.domain;

// Clase de dominio que modela un producto vendible.
// Mantén esta clase como POJO (Plain Old Java Object) para facilitar pruebas y reutilización.
public class Product {
    private final String id;      // Identificador único del producto (p.ej. SKU)
    private final String name;    // Nombre visible para el cliente
    private final String category;// Categoría simple (p.ej. "POLERAS", "PANTALONES")
    private final double price;   // Precio base, sin descuentos

    public Product(String id, String name, String category, double price) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
}