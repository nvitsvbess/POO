package cl.duoc.domain;

import java.time.LocalDateTime;
import java.util.List;

// Orden finalizada: snapshot de los totales y descuentos aplicados.
// Inmutable para evitar inconsistencias post-creación.
public class Order {
    private final List<CartItem> items;     // Ítems al momento de confirmar
    private final double subtotal;          // Suma de (precio * cantidad)
    private final double totalDiscount;     // Monto total descontado (>= 0)
    private final double totalToPay;        // subtotal - totalDiscount (nunca negativo)
    private final LocalDateTime createdAt;  // Marca temporal de creación

    public Order(List<CartItem> items, double subtotal, double totalDiscount, double totalToPay) {
        this.items = List.copyOf(items); // Copia inmutable
        this.subtotal = subtotal;
        this.totalDiscount = totalDiscount;
        this.totalToPay = totalToPay;
        this.createdAt = LocalDateTime.now();
    }

    public List<CartItem> getItems() { return items; }
    public double getSubtotal() { return subtotal; }
    public double getTotalDiscount() { return totalDiscount; }
    public double getTotalToPay() { return totalToPay; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}