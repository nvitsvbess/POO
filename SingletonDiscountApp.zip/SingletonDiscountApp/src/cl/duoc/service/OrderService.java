package cl.duoc.service;

import cl.duoc.domain.Order;
import cl.duoc.domain.ShoppingCart;
import cl.duoc.discount.DiscountManager;

// Capa de aplicación: orquesta el proceso de checkout sin conocer detalles de descuentos.
public class OrderService {
    private final DiscountManager discountManager = DiscountManager.getInstance(); // Acceso global controlado

    public Order checkout(ShoppingCart cart) {
        if (cart.isEmpty()) throw new IllegalStateException("El carrito está vacío");
        double subtotal = cart.getSubtotal();
        double totalDiscount = discountManager.computeTotalDiscount(cart);
        totalDiscount = Math.min(totalDiscount, subtotal); // Nunca exceder subtotal
        double toPay = subtotal - totalDiscount;
        return new Order(cart.getItems(), subtotal, totalDiscount, toPay);
    }
}